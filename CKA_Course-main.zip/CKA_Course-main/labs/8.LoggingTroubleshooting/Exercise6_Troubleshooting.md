 ## Exercise 6: Troubleshooting
  


The same 2 tier application is deployed in the zeta namespace. It must display a green web page on success. Click on the app tab at the top of your terminal to view your application. It is currently failed. Troubleshoot and fix the issue.

<details><summary>Show</summary>
<p>

```bash
Ans
```

</p>
</details>
