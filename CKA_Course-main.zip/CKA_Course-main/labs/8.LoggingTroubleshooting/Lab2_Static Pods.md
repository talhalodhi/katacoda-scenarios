 ## Lab : Static Pods
   
  1.  Create a simple web server as a static Pod
    
<details><summary>Show</summary>
<p>

```bash
Ans
```

</p>
</details>
  

2.  Create a static pod named static-busybox that uses the busybox image and the command sleep 1000

<details><summary>Show</summary>
<p>

```bash
Ans
```

</p>
</details>
