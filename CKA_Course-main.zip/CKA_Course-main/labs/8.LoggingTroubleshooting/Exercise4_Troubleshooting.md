 ## Exercise 4 : Troubleshooting
  


The same 2 tier application is deployed in the delta namespace. It must display a green web page on success. It is currently failed. Troubleshoot and fix the issue.

<details><summary>Show</summary>
<p>

```bash
Ans
```

</p>
</details>
