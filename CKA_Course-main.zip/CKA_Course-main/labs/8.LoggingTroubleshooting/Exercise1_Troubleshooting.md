 ## Exercise 1 : Troubleshooting
  



A simple 2 tier application needs to be deployed in the alpha namespace using alpha.yaml file. It must display a green web page on success. Try to browse the app on the node ip and port once deployed. It is currently failed. Troubleshoot and fix the issue.

<details><summary>Show</summary>
<p>

```bash
Ans
```

</p>
</details>
