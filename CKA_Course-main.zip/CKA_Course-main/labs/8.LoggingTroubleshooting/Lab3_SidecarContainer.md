 ## Lab : Sidecar container
   
 Create a pod using image kodekloud/event-simulator. Check the logs of the pod.
    
<details><summary>Show</summary>
<p>

```bash
Ans
```

</p>
</details>
  

