 ## Exercise 2 : Troubleshooting
  



Deploy the application using beta.yaml file. It must display a green web page on success when browsed through the node ip address and node port... It is currently failed. Troubleshoot and fix the issue.

<details><summary>Show</summary>
<p>

```bash
Ans
```

</p>
</details>
