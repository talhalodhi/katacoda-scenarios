Lab 2 - Upgrade 2

https://kubernetes.io/docs/tasks/administer-cluster/kubeadm/kubeadm-upgrade/
